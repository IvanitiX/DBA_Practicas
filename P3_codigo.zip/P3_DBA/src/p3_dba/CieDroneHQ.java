package p3_dba;

import IntegratedAgent.IntegratedAgent;
import Map2D.Map2DGrayscale;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import YellowPages.YellowPages;
import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
 */
public class CieDroneHQ extends IntegratedAgent{
    
    private static String IDENTITY_MANAGER = "Sphinx";
    
    private String worldManager;
    private String status;
    private YellowPages pags;
    private String convID;
    private Map2DGrayscale map;
    private int posx, posy;
    private List<String> coins; 
    
    // Variables relacionadas con los Marketplaces
    private String marketplaces[];
    private ArrayList<String> catalogueAngular, catalogueDistance, catalogueEnergy;
    private ArrayList<String> drones;
    private String infoAngular, infoDistance;
    private List<String> infoEnergy;
    
    // Mensajes de envío y recepción de cada agente
    private ACLMessage identityManagerSender, identityManagerReceiver;
    private ACLMessage marketplaceSender, marketplaceReceiver;
    private ACLMessage worldManagerSender, worldManagerReceiver;
    private ACLMessage listenerSender, listenerReceiver;
    private ACLMessage droneSender, droneReceiver;
    
    // Parámetros leídos por los sensores
    private float angular;
    private float distance;
    
    // Parámetros interpretados
    private int compass;
    private int currentX, currentY, currentZ;
    private int energy;
    private int objectiveX, objectiveY;
    private Map actionsCost;
    private int sensorsEnergyWaste;
    private int nextStepHeight;
    
    /**
     * Inicializa los componentes del agente
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    @Override
    public void setup(){
        super.setup();
        
        status = "deploy";
        
        pags = new YellowPages();
        map = new Map2DGrayscale();
        
        listenerSender = new ACLMessage();
        identityManagerSender = new ACLMessage();
        marketplaceSender = new ACLMessage();
        worldManagerSender = new ACLMessage();
        droneSender = new ACLMessage();
        
        actionsCost = new HashMap<Integer, Double>();
        coins = new ArrayList<>();
        catalogueAngular = new ArrayList<>();
        catalogueDistance = new ArrayList<>();
        catalogueEnergy = new ArrayList<>();
        infoEnergy = new ArrayList<>();
        drones = new ArrayList<>();
        
        drones.add("CieDroneHQ1");
        drones.add("CieDroneHQ2");
        drones.add("CieDroneHQ3");
        drones.add("CieDroneHQ4");
        drones.remove(this.getLocalName());
        
        for (int i=0; i<drones.size(); i++){
            droneSender.addReceiver(new AID(drones.get(i), AID.ISLOCALNAME));
        }
        droneSender.setSender(this.getAID());
        
        infoDistance = "";
        infoAngular = "";
        sensorsEnergyWaste = 9;
        compass = 90;
        energy = 10;
        
        _exitRequested = false ;
    }
    
    /**
     * Realiza el Take Down del agente
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    @Override
    public void takeDown() {
        
        super.takeDown();
    }
    
    /**
     * Este método, en función del estado del agente en cada iteración, delega la ejecución de dicha iteración a un método diferente
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    @Override
    public void plainExecute() {
        switch(status){
            case "deploy":
                deploy();
            break;
            case "market":
                market();
            break;
            case "login":
                login();
            break;
            case "readSensors":
                readSensors();
            break;
            case "findObjective":
                findObjective();
            break;
            case "logout":
                logout();
            break;
            case "exit":
                _exitRequested = true;
            break;
        }
    } 
    
    
    /**
     * Despliega el agente, realizando la suscripción tanto al Identity Manager como al World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void deploy(){
        
        // Esperamos inicialmente el mensaje de CieListener con el mapa, posición e id de la conversación
        this.getInitialInfo();
        
        // ***** IDENTITY MANAGER *****
        
        // Suscripción a Identity Manager
        identityManagerSender.setSender(this.getAID());
        identityManagerSender.addReceiver(new AID(IDENTITY_MANAGER,AID.ISLOCALNAME));
        identityManagerSender.setPerformative(ACLMessage.SUBSCRIBE);
        identityManagerSender.setProtocol("ANALYTICS");
        identityManagerSender.setEncoding(_myCardID.getCardID());
        identityManagerSender.setContent("{}");
        
        // Creamos template para detectar en el futuro aquellas respuestas que referencien a la clave key
        String key = "L_IM";
        identityManagerSender.setReplyWith(key);
        
        MessageTemplate template = MessageTemplate.MatchInReplyTo(key);
        
        this.send(identityManagerSender);
        
        identityManagerReceiver = this.blockingReceive(template);
        
        //Si la respuesta es REFUSE o NOT_UNDERSTOOD, salimos
        if (identityManagerReceiver.getPerformative() != ACLMessage.CONFIRM && 
                identityManagerReceiver.getPerformative() != ACLMessage.INFORM){
            
            status = "exit";
            return;
        }
        
        System.out.println("Agente " + this.getAID().getLocalName() + " suscrito a IM");
        
        // Creamos respesta al IM para obtener páginas amarillas
        ACLMessage getYP = identityManagerReceiver.createReply();
        getYP.setPerformative(ACLMessage.QUERY_REF);
        getYP.setContent("{}");
        getYP.setReplyWith(key);
        this.send(getYP);

        identityManagerReceiver = this.blockingReceive(template);

        //Si la respuesta es REFUSE o NOT_UNDERSTOOD, hacemos logout en la plataforma
        if(identityManagerReceiver.getPerformative() != ACLMessage.CONFIRM && 
                identityManagerReceiver.getPerformative() != ACLMessage.INFORM){
            
            status = "logout";
            return;
        }
        
        // Actualizamos páginas amarillas a partir de la respuesta del IM
        pags.updateYellowPages(identityManagerReceiver) ;
        System.out.println(pags.prettyPrint());
        worldManager = pags.queryProvidersofService("Analytics group Cie Automotive").toArray()[0].toString();
        Info("El World Manager es " + worldManager);

        
        // ***** WORLD MANAGER *****
        
        // Suscripción al World Manager
        worldManagerSender.setSender(this.getAID());
        worldManagerSender.addReceiver(new AID(worldManager, AID.ISLOCALNAME));
        worldManagerSender.setPerformative(ACLMessage.SUBSCRIBE);
        worldManagerSender.setProtocol("REGULAR");
        worldManagerSender.setConversationId(convID);
        worldManagerSender.setEncoding(_myCardID.getCardID());
        String content = this.getDeploymentMessage().toString();
        worldManagerSender.setContent(content);
        this.send(worldManagerSender);
        
        worldManagerReceiver = this.blockingReceive();
        
        // Si la respuesta es REFUSE o NOT_UNDERSTOOD, hacemos logout en la plataforma
        if(worldManagerReceiver.getPerformative() != ACLMessage.INFORM){
            
            status = "logout";
            return;
        }
        
        String deployInfo = worldManagerReceiver.getContent();
        System.out.println("Agente " + this.getAID().getLocalName() + " ha obtenido respuesta del WM: " + deployInfo);
       
        // Esperando respuesta
        JsonObject parsedDeployInfo;
        parsedDeployInfo = Json.parse(deployInfo).asObject();
        
        if (parsedDeployInfo.get("result").asString().equals("ok")){
            
            // Obtenemos recursos
            for (int i=0; i<parsedDeployInfo.get("coins").asArray().size(); i++){
                coins.add(parsedDeployInfo.get("coins").asArray().get(i).asString());
            }
            status = "market";
        }
        else{
            status = "logout";
        }
    }
    
    
    /**
     * Determina el objetivo al que el drone debe dirigirse y toma la mejor acción posible para aproximarse a él
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @return action Acción a realizar
     */
    protected String determineAction(){
        
        // Determinamos la distancia euclídea con respecto al objetivo de las casillas que nos rodean
        obtainActionsCost();
        
        nextStepHeight = Integer.MIN_VALUE;
        
        String action = "";
        
        // Calculamos el ángulo que ha de girar el dron para orientarse hacia la casilla adyacente que presento una menor distancia euclídea con respecto al objetivo
        int angle = getNextStepAngle();
        // Calculamos la diferencia entre compass y el ángulo que el dron tiene que girar para orientarse a la siguiente mejor casilla según la heurística
        int dif = (int) (compass - angle);
        
        if (dif == 0){ // Si el dron está orientado hacia el objetivo
            action = "moveF";
            if (compass - 0 < 0.1 && compass - 0 > -0.1)
                nextStepHeight = map.getLevel(currentX, currentY-1);
            else if (compass - 45 < 0.1 && compass - 45 > -0.1)
                nextStepHeight = map.getLevel(currentX+1, currentY-1);
            else if (compass - 90 < 0.1 && compass - 90 > -0.1)
                nextStepHeight = map.getLevel(currentX+1, currentY);
            else if (compass - 135 < 0.1 && compass - 135 > -0.1)
                nextStepHeight = map.getLevel(currentX+1, currentY+1);
            else if (compass - 180 < 0.1 && compass - 180 > -0.1)
                nextStepHeight = map.getLevel(currentX, currentY+1);
            else if (compass - (-135) < 0.1 && compass - (-135) > -0.1)
                nextStepHeight = map.getLevel(currentX-1, currentY+1);
            else if (compass - (-90) < 0.1 && compass - (-90) > -0.1)
                nextStepHeight = map.getLevel(currentX-1, currentY);
            else if (compass - (-45) < 0.1 && compass - (-45) > -0.1)
                nextStepHeight = map.getLevel(currentX-1, currentY-1);
            
            if (nextStepHeight > currentZ)
                action = "moveUP";
        }
        else if (dif < 0){ // En caso contrario, si la diferencia es negativa, probamos a evaluar un giro hacia la derecha para orientar al dron hacia el objetivo
            if (Math.abs(dif) > 180) // No es conveniente girar a la derecha
                action = "rotateL";
            else
                action = "rotateR";
        }
        else{ // Si la diferencia es positiva, probamos a evaluar un giro hacia la izquierda para orientar al dron hacia el objetivo
            if (Math.abs(dif) > 180) // No es conveniente girar a la izquierda
                action = "rotateR";
            else
                action = "rotateL";
        }
        
        return action;
    }
    
    
    /**
     * Evalúa si el dron se encuentra sobre el objetivo y, en caso afirmativo, determina la acción a realizar para llevar a cabo su rescate si es el objetivvo principal
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @param act Acción determinada a realizar justo antes de llamar a este método
     * @return action Acción elegida por el método
     */
    protected String evaluateObjective (String act){
        String action = act;
        
        if (currentX == objectiveX && currentY == objectiveY){
            
            if (currentX == posx && currentY == posy){
                if (currentZ - map.getLevel(currentX, currentY) >= 5)
                    action = "moveD";
                else{
                    action = "touchD";
                    status = "readSensors";
                }
            }
            else if (currentZ - map.getLevel(currentX, currentY) >= 5)
                action = "moveD";
            else if ((currentZ - map.getLevel(currentX, currentY)) < 5 && (currentZ - map.getLevel(currentX, currentY)) > 0)
                action = "touchD";
            else if (energy < 10)
                action = "recharge";
            else{
                action = "rescue";
                
                if (action.equals("rescue")){
                    droneSender.setProtocol("OBJECTIVE_REACHED");
                    droneSender.setPerformative(ACLMessage.INFORM);
                    droneSender.setContent(objectiveX+"@"+objectiveY);
                    this.send(droneSender);

                    System.out.println(this.getLocalName()+": el objetivo "+objectiveX+","+objectiveY+" se ha liberado");
                }
                
                status = "readSensors";
            }
        }
        
        return action;
    }
    
    /**
     * Evalúa si va a ser necesaria la recarga en la presente iteración en función del coste de energía actual o de la siguiente casilla a la que se moverá el dron.
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @param act Acción determinada a realizar justo antes de llamar a este método
     * @return action Acción elegida por el método
     */
    protected String evaluateRecharge (String act){
        String action = act;
        
        if (action.equals("moveF") || action.equals("moveUP")){ 
            // Se evalúa si se ha de recargar antes de avanzar a la siguiente casilla
            if((energy-4*Math.abs(currentZ-nextStepHeight)) < 15){ 
                if (currentZ - map.getLevel(currentX, currentY) >= 5)
                    action = "moveD";
                else if ((currentZ - map.getLevel(currentX, currentY)) < 5 && (currentZ - map.getLevel(currentX, currentY)) > 0)
                    action = "touchD";
                else
                    action = "recharge";
            }
        }
        else{
            // Se evalúa si se ha de recargar de inmediato
            if((energy-4*(currentZ-map.getLevel(currentX, currentY))) < 15){ 
                if (currentZ - map.getLevel(currentX, currentY) >= 5)
                    action = "moveD";
                else if ((currentZ - map.getLevel(currentX, currentY)) < 5 && (currentZ - map.getLevel(currentX, currentY)) > 0)
                    action = "touchD";
                else
                    action = "recharge";
            }
        }
        
        return action;
    }
    
    /**
     * Determina y ejecuta una acción en función de las percepciones del mundo y el estado del agente
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void findObjective(){
        
        String action = "";
        
        // Determinamos la acción a realizar en base a la distancia al objetivo y la posición actual del drone
        action = determineAction();
        
        // Evaluamos si tenemos que recargar y actualizamos la acción consecuentemente
        action = evaluateRecharge(action);
         
        // Si hemos alcanzado el objetivo, descendemos
        action = evaluateObjective(action);
        
        if (action.equals("rescue")){
            Info("Rescatando al objetivo");
        }
        
        // Enviamos el mensaje con la acción
        sendAction(action);
       
        // Esperando respuesta
        JsonObject parsedResult = receiveAnswerToAction();
        
        // En función de la respuesta del servidor, actualizamos el estado del agente
        if (parsedResult.get("result").asString().equals("ok") && !(status.equals("logout")) && !(status.equals("readSensors"))){
            
            // Actualizamos parámetros
            this.updateParameters(action);
            
            status = "findObjective";
        }
        else if (!status.equals("readSensors")){
            status = "logout";
        }
    }
    
    /**
     * Codifica la acción para enviarla al servidor
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @param action Acción a enviar en formato String
     * @return actions Acción a realizar en formato JsonObject
     */
    protected JsonObject getActions (String action){
        JsonObject actions = new JsonObject();
        
        actions.add("operation",action);
        
        if (action.equals("recharge") && infoEnergy.isEmpty()){
            System.out.println(this.getLocalName()+": el drone tiene que recargar y no tiene energía");
            
            MessageTemplate template = MessageTemplate.MatchProtocol("SEND_TICKETS");
            droneReceiver = this.blockingReceive(template);
            
            String split [] = droneReceiver.getContent().split("@");
            
            for (int i=0; i<split.length; i++){
                infoEnergy.add(split[i]);
            }
        }
        
        if (action.equals("recharge") && !infoEnergy.isEmpty()){
            actions.add("recharge", infoEnergy.get(0));
            infoEnergy.remove(0);
        }
        
        return actions;
    }
    
    
    /**
     * Codifica la información necesaria para suscribirse al World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @return deployInfo Información de despliegue en formato JsonObject
     */
    protected JsonObject getDeploymentMessage (){
        JsonObject deployInfo = new JsonObject();
        
        deployInfo.add("type", "RESCUER");
        
        return deployInfo;
    }
    
    
    /**
     * Devuelve la distancia euclídea del punto cardinal introducido por parámetros con respecto al objetivo
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @param posX Coordenada X del punto cardinal a evaluar
     * @param posY Coordenada Y del punto cardinal a evaluar
     * @return Distancia euclídea del punto cardinal introducido por parámetros con respecto al objetivo
     */
    protected double getDistanceToObjective(int posX, int posY){
        return Math.sqrt(Math.pow(objectiveX-posX,2) + Math.pow(objectiveY-posY,2));
    }
    
    
    /**
     * Obtiene la información inicial procedente del Listener
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void getInitialInfo(){
        
        MessageTemplate template = MessageTemplate.and(MessageTemplate.MatchProtocol("INITIALIZE"), 
                MessageTemplate.MatchSender(new AID("CieListener", AID.ISLOCALNAME)));
        
        listenerReceiver = this.blockingReceive(template);
        
        System.out.println("Agente " + this.getAID().getLocalName() + " ha recibido el mensaje del listener");
        
        String initialInfo = listenerReceiver.getContent();
        JsonObject parsedInitialInfo = Json.parse(initialInfo).asObject();
        
        convID = parsedInitialInfo.get("convID").asString();
        posx = parsedInitialInfo.get("posx").asInt();
        posy = parsedInitialInfo.get("posy").asInt();
        
        // Obtenemos el mapa
        JsonObject mapJsonFormat = parsedInitialInfo.get("map").asObject();
        mapJsonFormat.set("filename", this.getLocalName()+".png");
        
        if (!map.fromJson(mapJsonFormat)) {
            System.out.println(this.getLocalName()+" - Problema al generar el mapa");
            status = "logoutIM";
            return;
        }
        
        // Actualizamos variables gps
        currentX = posx;
        currentY = posy;
        currentZ = map.getLevel(posx, posy);
    }
    
    /**
     * Codifica la información necesaria para iniciar sesión en el World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @return loginInfo Información de login en formato JsonObject
     */
    protected JsonObject getLoginInfo(){
        JsonObject loginInfo = new JsonObject();
        JsonArray sensorListJsonFormat = new JsonArray();
        
        loginInfo.add("operation", "login");
        loginInfo.add("posx", posx);
        loginInfo.add("posy", posy);
        
        // Asociamos a la clave "attach" todos los tickets comprados en los Marketplaces
        sensorListJsonFormat.add(infoAngular);
        sensorListJsonFormat.add(infoDistance);
        
        for (int i=0; i<infoEnergy.size(); i++){
            sensorListJsonFormat.add(infoEnergy.get(i));
        }
            
        loginInfo.add("attach", sensorListJsonFormat);
        
        return loginInfo;
    }
    
    /**
     * Obtiene el ángulo que el drone tiene que girar para orientarse a la siguiente mejor casilla según la heurística
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @return angle El ángulo que el dron tiene que girar para orientarse a la siguiente mejor casilla según la heurística
     */
    protected int getNextStepAngle(){
        int angle = 0;
        
        Iterator it = actionsCost.entrySet().iterator();
        
        double minDist = Double.MAX_VALUE;
        
        while(it.hasNext()){ // Recorremos la matriz de costes en busca del ángulo más óptimo
            Map.Entry pair = (Map.Entry) it.next();
            
            if ((double) pair.getValue() < minDist){
                minDist = (double) pair.getValue();
                angle = (int) pair.getKey();
            }
        }
        
        // El ángulo devuelto será el que nos lleve a la con menor distancia euclídea con respecto al objetivo
        return angle;
    }
    
    /**
     * Codifica la información necesaria para realizar la compra de un ticket
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @return purchaseInfo Información de compra de un ticket en formato JsonObject
     */
    protected JsonObject getProductListMessage(String info){
        JsonObject purchaseInfo = new JsonObject();
        String [] splitInfo = info.split("@");
        JsonArray coinsJsonFormat = new JsonArray();
        
        purchaseInfo.add("operation", "buy");
        purchaseInfo.add("reference", splitInfo[1]);
        
        // En el caso de que no se disponga de suficientes recursos, el método devolverá null
        if (coins.size() < Integer.parseInt(splitInfo[0]))
            return null;
           
        for (int i=0; i<Integer.parseInt(splitInfo[0]); i++){
            coinsJsonFormat.add(coins.get(i));
        }
            
        purchaseInfo.add("payment", coinsJsonFormat);
        
        return purchaseInfo;
    }
    
    /**
     * Realiza el login del agente en el World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void login(){
        
        // Nos logueamos en el World Manager
        worldManagerSender = worldManagerReceiver.createReply();
        worldManagerSender.setPerformative(ACLMessage.REQUEST);
        worldManagerSender.setReplyWith("LOGIN_INFO");
        String content = this.getLoginInfo().toString();
        worldManagerSender.setContent(content);
        this.send(worldManagerSender);
        
        // Esperamos respuesta del World Manager
        MessageTemplate template = MessageTemplate.and(MessageTemplate.MatchSender(new AID(worldManager,AID.ISLOCALNAME)), 
                MessageTemplate.MatchInReplyTo("LOGIN_INFO"));
        worldManagerReceiver = this.blockingReceive(template);
        
        if (worldManagerReceiver.getPerformative() != ACLMessage.CONFIRM &&
                worldManagerReceiver.getPerformative() != ACLMessage.INFORM){
            System.out.println(this.getLocalName()+": el dron no ha podido hacer login en el mundo");
            status = "logout";
            return;
        }
        
        Info("Logueados en el sistema");
        
        // Esperamos confirmación de login del resto de drones
        droneSender.setProtocol("LOGIN");
        droneSender.setContent("");
        this.send(droneSender);
        
        for (int i=0; i<drones.size(); i++){
            template = MessageTemplate.and(MessageTemplate.MatchProtocol("LOGIN"),
                    MessageTemplate.MatchSender(new AID(drones.get(i), AID.ISLOCALNAME)));
            
            droneReceiver = this.blockingReceive(template);
        }
        status = "readSensors";
    }
    
    /**
     * Calcula, en base a la posición actual del dron, al ángulo que devuelve el sensor angular y a la distancia que devuelve el sensor distance; la posición en X e Y del objetivo
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void locateObjective(){
        objectiveX = (int) Math.round(currentX + distance*Math.sin(Math.toRadians(angular)));
        objectiveY = (int) Math.round(currentY - distance*Math.cos(Math.toRadians(angular)));
    }
    
    /**
     * Cancela la suscripción al agente Identity Manager y comunica logout al Listener
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void logout(){
        
        // Enviamos tickets de energía restantes al resto de drones
        droneSender.setProtocol("SEND_TICKETS");
        droneSender.setPerformative(ACLMessage.INFORM);
        
        String content = "";
        for (int i=0; i<infoEnergy.size(); i++){
            content += infoEnergy.get(i);
            
            if (i != infoEnergy.size()-1)
                content += "@";
        }
        droneSender.setContent(content);
        this.send(droneSender);
        
        // Cancelamos suscripción a Identity Manager
        identityManagerSender = identityManagerReceiver.createReply();
        identityManagerSender.setProtocol("ANALYTICS");
        identityManagerSender.setPerformative(ACLMessage.CANCEL);
        identityManagerSender.setContent("{}");
        this.send(identityManagerSender);
        
        // Informamos al listener para que cancele la suscripción
        listenerSender.addReceiver(new AID("CieListener", AID.ISLOCALNAME));
        listenerSender.setPerformative(ACLMessage.INFORM);
        listenerSender.setContent("loggingOut");
        this.send(listenerSender);
        
        status = "exit";
    }
    
    /**
     * Realiza todas las operaciones y controla las comunicaciones relacionadas con los Marketplaces
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void market(){
        // Obtenemos los nombres de los marketplaces con los que queremos comunicarnos
        marketplaces = new String[pags.queryProvidersofService("shop@"+convID).toArray().length];
        
        for (int i=0; i<marketplaces.length; i++){
            marketplaces[i] = (String) pags.queryProvidersofService("shop@"+convID).toArray()[i];
        }
        
        // Enviamos una solicitud a todos los marketplaces para obtener su catálogo
        marketplaceSender.setSender(this.getAID());
        marketplaceSender.setPerformative(ACLMessage.QUERY_REF);
        marketplaceSender.setConversationId(convID);
        marketplaceSender.setReplyWith("CIE_CATALOGUE");
        marketplaceSender.setProtocol("REGULAR");
        marketplaceSender.setContent("{}");
        for (int i=0; i<marketplaces.length; i++){
            marketplaceSender.addReceiver(new AID (marketplaces[i], AID.ISLOCALNAME));
        }
        this.send(marketplaceSender);
        
        // Recibimos respuesta de cada marketplace
        MessageTemplate template;
        
        for (int i=0; i<marketplaces.length; i++){
            template = MessageTemplate.and(MessageTemplate.MatchInReplyTo("CIE_CATALOGUE"), 
                MessageTemplate.MatchSender(new AID(marketplaces[i], AID.ISLOCALNAME)));
            
            marketplaceReceiver = this.blockingReceive(template);
            
            if (marketplaceReceiver.getPerformative() != ACLMessage.INFORM){
                Info ("Fallo al obtener el catálogo de " + marketplaces[i]);
            }
            else{
                JsonObject mkinfo = Json.parse(marketplaceReceiver.getContent()).asObject();
                
                for (int j=0; j<mkinfo.get("products").asArray().size(); j++){
                    
                    String reference = mkinfo.get("products").asArray().get(j).asObject().get("reference").asString();
                    int price = mkinfo.get("products").asArray().get(j).asObject().get("price").asInt();
                    
                    if (reference.contains("ANGULARHQ")){
                        catalogueAngular.add(price + "@" + reference + "@" + marketplaces[i]);
                    }
                    else if(reference.contains("DISTANCEHQ")){
                        catalogueDistance.add(price + "@" + reference + "@" + marketplaces[i]);
                    }    
                    else if (reference.contains("ENERGY")){
                        catalogueEnergy.add(price + "@" + reference + "@" + marketplaces[i]);
                    } 
                }
            }
        }
        
        // Ordenamos las listas de menor a mayor precio
        Collections.sort(catalogueAngular);
        Collections.sort(catalogueDistance);
        Collections.sort(catalogueEnergy);
        
        System.out.println("Catálogo angular:"+catalogueAngular);
        System.out.println("Catálogo distance:"+catalogueDistance);
        System.out.println("Catálogo energy:"+catalogueEnergy);
        
        // Realizamos la compra de los sensores correspondientes
        
        marketplaceSender.reset();
        marketplaceSender.setSender(this.getAID());
        marketplaceSender.setPerformative(ACLMessage.REQUEST);
        marketplaceSender.setConversationId(convID);
        marketplaceSender.setProtocol("REGULAR");
        
        String [] splitInfo;
        JsonObject content;
        
        // Obtenemos sensor ANGULAR:
        
        if (catalogueAngular.isEmpty()){
            System.out.println(this.getLocalName()+" - No hay ningún sensor angular disponible");
            status = "logout";
            return;
        }
        do{
            // Enviamos solicitud de compra al Marketplace con el sensor angular de menor coste
            splitInfo = catalogueAngular.get(0).split("@");
            marketplaceSender.addReceiver(new AID(splitInfo[2], AID.ISLOCALNAME));
            content = this.getProductListMessage(catalogueAngular.get(0));
            if (content == null){
                System.out.println(this.getLocalName()+" - No hay recursos disponibles para realizar la compra");
                status = "logout";
                return;
            }
            marketplaceSender.setContent(content.toString());
            marketplaceSender.setReplyWith("CIE_PURCHASE_ANGULAR"+this.getLocalName());
            this.send(marketplaceSender);
            
            // Extraemos el receptor para posteriores envíos
            marketplaceSender.removeReceiver(new AID(splitInfo[2], AID.ISLOCALNAME));

            // Esperamos respuesta del Marketplace
            template = MessageTemplate.and(MessageTemplate.MatchSender(new AID(splitInfo[2], AID.ISLOCALNAME)),
                        MessageTemplate.MatchInReplyTo("CIE_PURCHASE_ANGULAR"+this.getLocalName()));

            marketplaceReceiver = this.blockingReceive(template);

            if (marketplaceReceiver.getPerformative() != ACLMessage.INFORM){
                catalogueAngular.remove(0);
            }
            else{
                // En el caso de que el Marketplace devolviese el producto solicitado, 
                // retiramos los recursos utilizados
                for (int i=0; i<Integer.parseInt(splitInfo[0]); i++){
                    coins.remove(0);
                }
        
                infoAngular = Json.parse(marketplaceReceiver.getContent()).asObject().get("reference").asString();
                System.out.println(this.getLocalName()+": sensor angular comprado: "+infoAngular);
            }
        }while(marketplaceReceiver.getPerformative() != ACLMessage.INFORM);
        
        // Obtenemos sensor DISTANCE:
        
        if (catalogueDistance.isEmpty()){
            System.out.println(this.getLocalName()+" - No hay ningún sensor distance disponible");
            status = "logout";
            return;
        }
            
        do{
            // Enviamos solicitud de compra al Marketplace con el sensor distance de menor coste
            splitInfo = catalogueDistance.get(0).split("@");
            marketplaceSender.addReceiver(new AID(splitInfo[2], AID.ISLOCALNAME));
            content = this.getProductListMessage(catalogueDistance.get(0));
            if (content == null){
                System.out.println(this.getLocalName()+" - No hay recursos disponibles para realizar la compra");
                status = "logout";
                return;
            }
            marketplaceSender.setContent(content.toString());
            marketplaceSender.setReplyWith("CIE_PURCHASE_DISTANCE"+this.getLocalName());
            this.send(marketplaceSender);
            
            // Extraemos el receptor para posteriores envíos
            marketplaceSender.removeReceiver(new AID(splitInfo[2], AID.ISLOCALNAME));

            // Esperamos respuesta del Marketplace
            template = MessageTemplate.and(MessageTemplate.MatchSender(new AID(splitInfo[2], AID.ISLOCALNAME)),
                        MessageTemplate.MatchInReplyTo("CIE_PURCHASE_DISTANCE"+this.getLocalName()));

            marketplaceReceiver = this.blockingReceive(template);

            if (marketplaceReceiver.getPerformative() != ACLMessage.INFORM){
                catalogueDistance.remove(0);
            }
            else{
                // En el caso de que el Marketplace devolviese el producto solicitado, 
                // retiramos los recursos utilizados
                
                for (int i=0; i<Integer.parseInt(splitInfo[0]); i++){
                    coins.remove(0);
                }
                infoDistance = Json.parse(marketplaceReceiver.getContent()).asObject().get("reference").asString();
                System.out.println(this.getLocalName()+": sensor distance comprado: "+infoDistance);
            }
        }while(marketplaceReceiver.getPerformative() != ACLMessage.INFORM);
        
        // Obtenemos tickets ENERGÍA:
        
        if (catalogueEnergy.isEmpty()){
            System.out.println(this.getLocalName()+" - No hay ningún sensor energy disponible");
            status = "logout";
            return;
        }
        content = this.getProductListMessage(catalogueEnergy.get(0));
        
        boolean energyPurchased = false;
        
        while(content != null && !catalogueEnergy.isEmpty() && !energyPurchased){
            
            // Enviamos solicitud de compra al Marketplace con el ticket de energía de menor coste
            splitInfo = catalogueEnergy.get(0).split("@");
            marketplaceSender.addReceiver(new AID(splitInfo[2], AID.ISLOCALNAME));
            marketplaceSender.setContent(content.toString());
            marketplaceSender.setReplyWith("CIE_PURCHASE_ENERGY"+this.getLocalName());
            this.send(marketplaceSender);
            
             // Extraemos el receptor para posteriores envíos
            marketplaceSender.removeReceiver(new AID(splitInfo[2], AID.ISLOCALNAME));

             // Esperamos respuesta del Marketplace
            template = MessageTemplate.and(MessageTemplate.MatchSender(new AID(splitInfo[2], AID.ISLOCALNAME)),
                        MessageTemplate.MatchInReplyTo("CIE_PURCHASE_ENERGY"+this.getLocalName()));

            marketplaceReceiver = this.blockingReceive(template);

            if (marketplaceReceiver.getPerformative() == ACLMessage.INFORM){
                
                // En el caso de que el Marketplace devolviese el producto solicitado, 
                // retiramos los recursos utilizados
                for (int i=0; i<Integer.parseInt(splitInfo[0]); i++){
                    coins.remove(0);
                }
        
                infoEnergy.add(Json.parse(marketplaceReceiver.getContent()).asObject().get("reference").asString());
            
                if (infoEnergy.size() >= 3)
                    energyPurchased = true;
            }
            
            catalogueEnergy.remove(0);
            
            if (!catalogueEnergy.isEmpty())
                content = this.getProductListMessage(catalogueEnergy.get(0));
        }
        
        System.out.println(this.getLocalName()+": tickets de energía comprados: "+infoEnergy);
        
        status = "login";
    }
    
    
    /**
     * Inicializa la matriz de costes con todos los valores de las casillas que rodean al dron. El coste es inversamente proporcional a la distancia euclídea con respecto al objetivo actual. 
     * Si la posición está contenida en la memoria del dron, se le adjudica un valor infinito
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void obtainActionsCost(){
        
        if ((currentX < 0) || (currentY-1 < 0) || (currentX > map.getWidth()) || (currentY-1 > map.getHeight()))
            actionsCost.put(0, Double.MAX_VALUE);
        else
            actionsCost.put(0, this.getDistanceToObjective(currentX, currentY-1));
        
        if ((currentX+1 < 0) || (currentY-1 < 0) || (currentX+1 > map.getWidth()) || (currentY-1 > map.getHeight()))
            actionsCost.put(45, Double.MAX_VALUE);
        else
            actionsCost.put(45, this.getDistanceToObjective(currentX+1, currentY-1));
        
        if ((currentX+1 < 0) || (currentY < 0) || (currentX+1 > map.getWidth()) || (currentY > map.getHeight()))
            actionsCost.put(90, Double.MAX_VALUE);
        else
            actionsCost.put(90, this.getDistanceToObjective(currentX+1, currentY));
        
        if ((currentX+1 < 0) || (currentY+1 < 0) || (currentX+1 > map.getWidth()) || (currentY+1 > map.getHeight()))
            actionsCost.put(135, Double.MAX_VALUE);
        else
            actionsCost.put(135, this.getDistanceToObjective(currentX+1, currentY+1));
        
        if ((currentX < 0) || (currentY+1 < 0) || (currentX > map.getWidth()) || (currentY+1 > map.getHeight()))
            actionsCost.put(180, Double.MAX_VALUE);
        else
            actionsCost.put(180, this.getDistanceToObjective(currentX, currentY+1));
        
        if ((currentX-1 < 0) || (currentY+1 < 0) || (currentX-1 > map.getWidth()) || (currentY+1 > map.getHeight()))
            actionsCost.put(-135, Double.MAX_VALUE);
        else
            actionsCost.put(-135, this.getDistanceToObjective(currentX-1, currentY+1));
        
        if ((currentX-1 < 0) || (currentY < 0) || (currentX-1 > map.getWidth()) || (currentY > map.getHeight()))
            actionsCost.put(-90, Double.MAX_VALUE);
        else
            actionsCost.put(-90, this.getDistanceToObjective(currentX-1, currentY));
        
        if ((currentX-1 < 0) || (currentY-1 < 0) || (currentX-1 > map.getWidth()) || (currentY-1 > map.getHeight()))
            actionsCost.put(-45, Double.MAX_VALUE);
        else
            actionsCost.put(-45, this.getDistanceToObjective(currentX-1, currentY-1));
    }
    
    
    /**
     * Método encargado de obtener la información de los sensores procedente del World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    protected void readSensors(){
        
        // Enviamos solicitud de lectura de sensores al World Manager
        worldManagerSender.reset();
        worldManagerSender.setSender(this.getAID());
        worldManagerSender.addReceiver(new AID(worldManager, AID.ISLOCALNAME));
        worldManagerSender.setPerformative(ACLMessage.QUERY_REF);
        worldManagerSender.setProtocol("REGULAR");
        worldManagerSender.setConversationId(convID);
        JsonObject jsonContent = new JsonObject().add("operation", "read");
        String content = jsonContent.toString();
        worldManagerSender.setContent(content);
        String key = this.getAID().getLocalName()+"ReadSensors";
        worldManagerSender.setReplyWith(key);
        this.send(worldManagerSender);
        
        // Esperamos respuesta del World Manager
        MessageTemplate template = MessageTemplate.MatchInReplyTo(key);
        worldManagerReceiver = this.blockingReceive(template);
        
        // Si la respuesta es REFUSE o NOT_UNDERSTOOD, hacemos logout en la plataforma
        if(worldManagerReceiver.getPerformative() != ACLMessage.INFORM){
            status = "logout";
            return;
        }
        else{
            JsonObject sensorsInfo = Json.parse(worldManagerReceiver.getContent()).asObject();
            JsonArray sensorReadings = sensorsInfo.get("details").asObject().get("perceptions").asArray();
            angular = sensorReadings.get(0).asObject().get("data").asArray().get(0).asFloat();
            distance = sensorReadings.get(1).asObject().get("data").asArray().get(0).asFloat();
            
            // Actualizamos energía
            energy-=sensorsEnergyWaste;
            
            // Obtenemos inicialmente las coordenadas del objetivo
            locateObjective();
            
            if (distance > 0 && distance <= 150){
                
                // Comprobamos inicialmente si el objetivo seleccionado ya está siendo
                // rescatado por otro drone
                template = MessageTemplate.and(MessageTemplate.MatchProtocol("NEW_OBJECTIVE"), 
                        MessageTemplate.MatchContent(objectiveX+"@"+objectiveY));
                
                droneReceiver = this.blockingReceive(template, 4000);
                
                if (droneReceiver != null){
                    System.out.println(this.getLocalName()+": el objetivo "+objectiveX+","+objectiveY+" ya estaba seleccionado. Esperando respuesta");
                    
                    // Esperamos a que el objetivo seleccionado sea rescatado para volver a leer los sensores
                    template = MessageTemplate.and(MessageTemplate.MatchProtocol("OBJECTIVE_REACHED"), 
                        MessageTemplate.MatchContent(objectiveX+"@"+objectiveY));
                    
                    droneReceiver = this.blockingReceive(template);
                    
                    // Realizamos una espera para que los drones no detecten el mismo objetivo
                    // de forma simultánea
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(CieDroneHQ.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    System.out.println(this.getLocalName()+": el objetivo "+objectiveX+","+objectiveY+" ha sido liberado");
                    
                    status = "readSensors";
                    return;
                }
                else{
                    System.out.println(this.getLocalName()+": el objetivo "+objectiveX+","+objectiveY+"no estaba seleccionado");
                }
                
                // Enviamos mensaje a los drones indicando la selección de un objetivo determinado
                droneSender.setProtocol("NEW_OBJECTIVE");
                droneSender.setPerformative(ACLMessage.INFORM);
                droneSender.setContent(objectiveX+"@"+objectiveY);
                this.send(droneSender);
                
                System.out.println(this.getLocalName()+": seleccionado objetivo "+objectiveX+","+objectiveY);
                
                status = "findObjective";
            }else{
                objectiveX = posx;
                objectiveY = posy;
                
                if (objectiveX == currentX && objectiveY == currentY && currentZ == map.getLevel(currentX, currentY))
                    status = "logout";
                else
                    status = "findObjective";
            }
            
        }
    }
    
    /**
     * Recibe la respuesta al envío de una acción al servidor
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @return parsedResult Respuesta al envío de la acción al servidor codificada en formato JsonObject
     */
    protected JsonObject receiveAnswerToAction (){
        MessageTemplate template = MessageTemplate.MatchInReplyTo("ACTIONKEY");
        
        worldManagerReceiver = this.blockingReceive(template);
        String result = worldManagerReceiver.getContent();
        JsonObject parsedResult;
        parsedResult = Json.parse(result).asObject();
        
        return parsedResult;
    }
    
    /**
     * Envía al servidor la acción elegida para realizar en formato JsonObject
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @param act Acción elegida para realizar en formato String
     */
    protected void sendAction (String act){
        String action = act;
        
        JsonObject actionToSend = getActions(action);
        worldManagerSender.setPerformative(ACLMessage.REQUEST);
        worldManagerSender.setContent(actionToSend.toString());
        worldManagerSender.setReplyWith("ACTIONKEY");
        
        this.sendServer(worldManagerSender);
    }
    
    /**
     * Actualiza los parámetros tras la ejecución de una acción determinada
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @param act Acción ejecutada en formato String
     */
    protected void updateParameters(String action){
        
        // Actualización de compass
        if (action.equals("rotateL")){
            if (compass > -135){
                compass-=45;
            }
            else{
                compass=180-Math.abs(compass)+135;
            }
        }
        else if (action.equals("rotateR")){
            if (compass <= 135){
                compass+=45;
            }
            else{
                compass=-180+Math.abs(compass)-135;
            }
        }
        // Actualización de gps
        else if (action.equals("moveF")){
            if (compass == 0){
                currentY--;
            }
            else if (compass == 45){
                currentX++;
                currentY--;
            }
            else if (compass == 90){
                currentX++;
            }
            else if (compass == 135){
                currentX++;
                currentY++;
            }
            else if (compass == 180){
                currentY++;
            }
            else if (compass == -135){
                currentX--;
                currentY++;
            }
            else if (compass == -90){
                currentX--;
            }
            else if (compass == -45){
                currentX--;
                currentY--;
            }
        }
        else if (action.equals("moveUP")){
            currentZ+=5;
        }
        else if (action.equals("moveD")){
            currentZ-=5;
        }
        else if (action.equals("touchD")){
            currentZ=map.getLevel(currentX, currentY);
        }

        // Actualización de energía
        if (action.equals("rotateR") || action.equals("rotateL") || action.equals("moveF"))
            energy-=4;
        else if (action.equals("moveUP") || action.equals("moveD") || action.equals("touchD"))
            energy-=20;
        else if (action.equals("recharge"))
            energy=1000;
    }
}
