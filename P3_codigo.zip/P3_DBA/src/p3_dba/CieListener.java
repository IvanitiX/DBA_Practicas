
package p3_dba;

import IntegratedAgent.IntegratedAgent;
import Map2D.Map2DGrayscale;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import YellowPages.YellowPages;
import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonObject;

/**
 * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
 */
public class CieListener extends IntegratedAgent{
    
    private static String IDENTITY_MANAGER = "Sphinx" ;
    
    private String worldManager;
    private String status;
    private YellowPages pags;
    private String worldName;
    private String convID;
    private Map2DGrayscale map;
    private JsonObject mapJsonFormat;
    
    // Mensajes de envío y recepción de cada agente
    private ACLMessage identityManagerSender, identityManagerReceiver;
    private ACLMessage worldManagerSender, worldManagerReceiver;
    private ACLMessage droneSender, droneReceiver;
    
    /**
     * Inicializa los componentes del agente
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    @Override
    public void setup(){
        super.setup();
        
        worldName = "World4";
        status = "deploy";
        
        identityManagerSender = new ACLMessage();
        worldManagerSender = new ACLMessage();
        droneSender = new ACLMessage();
        
        map = new Map2DGrayscale();
        
        pags = new YellowPages();
        _exitRequested = false ;
    }
    
    /**
     * Realiza el Take Down del agente
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    @Override
    public void takeDown() {
        
        super.takeDown();
    }
    
    /**
     * Este método, en función del estado del agente en cada iteración, delega la ejecución de dicha iteración a un método diferente
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    @Override
    public void plainExecute() {
        switch(status){
            case "deploy":
                deploy();
            break;
            case "sendInitialInfo":
                sendInitialInfo();
            break;
            case "logoutWM":
                logoutWM();
            break;
            case "logoutIM":
                logoutIM();
            break;
            case "exit":
                _exitRequested = true;
            break;
        }
    } 
    
    /**
     * Despliega el agente, realizando la suscripción tanto al Identity Manager como al World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    public void deploy(){
        
        // ******************** IDENTITY MANAGER ********************
        
        // Suscripción a Identity Manager
        identityManagerSender.setSender(this.getAID());
        identityManagerSender.addReceiver(new AID(IDENTITY_MANAGER,AID.ISLOCALNAME));
        identityManagerSender.setPerformative(ACLMessage.SUBSCRIBE);
        identityManagerSender.setProtocol("ANALYTICS");
        identityManagerSender.setEncoding(_myCardID.getCardID());
        identityManagerSender.setContent("{}");
        
        // Creamos template para detectar en el futuro aquellas respuestas que referencien a la clave key
        String key = "L_IM";
        identityManagerSender.setReplyWith(key);
        
        MessageTemplate template = MessageTemplate.MatchInReplyTo(key);
        
        this.send(identityManagerSender);
        
        identityManagerReceiver = this.blockingReceive(template);
        
        //Si la respuesta es REFUSE o NOT_UNDERSTOOD, salimos
        if (identityManagerReceiver.getPerformative() != ACLMessage.CONFIRM && 
                identityManagerReceiver.getPerformative() != ACLMessage.INFORM){
            
            status = "exit";
            return;
        }
        
        // Creamos respesta al IM para obtener páginas amarillas
        ACLMessage getYP = identityManagerReceiver.createReply();
        getYP.setPerformative(ACLMessage.QUERY_REF);
        getYP.setContent("{}");

        getYP.setReplyWith(key);
        
        //template = MessageTemplate.MatchInReplyTo(key);

        this.send(getYP);

        identityManagerReceiver = this.blockingReceive(template);

        //Si la respuesta es REFUSE o NOT_UNDERSTOOD, hacemos logout en la plataforma
        if(identityManagerReceiver.getPerformative() != ACLMessage.CONFIRM && 
                identityManagerReceiver.getPerformative() != ACLMessage.INFORM){
            
            status = "logoutIM";
            return;
        }
        
        // Actualizamos páginas amarillas a partir de la respuesta del IM
        pags.updateYellowPages(identityManagerReceiver) ;
        System.out.println(pags.prettyPrint());
        worldManager = pags.queryProvidersofService("Analytics group Cie Automotive").toArray()[0].toString();
        Info("El World Manager es " + worldManager);

        // ******************** WORLD MANAGER ********************
        
        // Suscripción al World Manager
        worldManagerSender.setSender(this.getAID());
        worldManagerSender.addReceiver(new AID(worldManager, AID.ISLOCALNAME));
        worldManagerSender.setPerformative(ACLMessage.SUBSCRIBE);
        worldManagerSender.setProtocol("ANALYTICS");
        //worldManagerSender.setEncoding(_myCardID.getCardID());
        String content = this.getDeploymentMessage().toString();
        worldManagerSender.setContent(content);
        this.send(worldManagerSender);
        
        worldManagerReceiver = this.blockingReceive();
        
        // Si la respuesta es REFUSE o NOT_UNDERSTOOD, hacemos logout en la plataforma
        if(worldManagerReceiver.getPerformative() != ACLMessage.INFORM){
            status = "logoutIM";
            return;
        }
        System.out.println("Listener logueado con éxito en WM!");
        
        String deployInfo = worldManagerReceiver.getContent();
        Info(deployInfo);
       
        // Esperando respuesta
        JsonObject parsedDeployInfo;
        parsedDeployInfo = Json.parse(deployInfo).asObject();
        
        if (parsedDeployInfo.get("result").asString().equals("ok")){
            
            // Inicializamos matriz del mapa
            mapJsonFormat = parsedDeployInfo.get("map").asObject();
            
            // Generamos el mapa
            if (!map.fromJson(mapJsonFormat)) {
                System.out.println("Problema al generar el mapa");
                status = "logoutIM";
                return;
            }
            
            convID = worldManagerReceiver.getConversationId();
            
            ACLMessage awacsSender = new ACLMessage();
            awacsSender.setSender(this.getAID());
            awacsSender.addReceiver(new AID("CieAwacs", AID.ISLOCALNAME));
            awacsSender.setPerformative(ACLMessage.QUERY_IF);
            awacsSender.setProtocol("ANALYTICS");
            //worldManagerSender.setEncoding(_myCardID.getCardID());
            awacsSender.setContent("");
            awacsSender.setConversationId(convID);
            this.send(awacsSender);
            
            status = "sendInitialInfo";
        }
        else{
            status = "logoutIM";
        }
    }
    
    /**
     * Codifica la información necesaria para suscribirse al World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @return deployInfo Información de deploy en formato JsonObject
     */
    private JsonObject getDeploymentMessage (){
        JsonObject deployInfo = new JsonObject();
        
        deployInfo.add("problem", worldName);
        
        return deployInfo;
    }
    
    /**
     * Codifica la información necesaria para que un drone pueda realizar login en el World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     * @return initialInfo Información inicial para un drone en formato JsonObject
     */
    private JsonObject getInitialInfoMessage(int posx, int posy){
        JsonObject initialInfo = new JsonObject();
        
        initialInfo.add("convID", convID);
        initialInfo.add("map", mapJsonFormat);
        initialInfo.add("posx", posx);
        initialInfo.add("posy", posy);
        
        return initialInfo;
    }
    
    /**
     * Cancela la suscripción al agente Identity Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    private void logoutIM(){
        
        // Cancelamos suscripción a Identity Manager
        identityManagerSender = identityManagerReceiver.createReply();
        identityManagerSender.setProtocol("ANALYTICS");
        identityManagerSender.setPerformative(ACLMessage.CANCEL);
        identityManagerSender.setContent("{}");
        this.send(identityManagerSender);
        
        status = "exit";
    }
    
    /**
     * Realiza el cierre de sesión en el World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    private void logoutWM(){
        // Antes de desloguearse, debe esperar de forma bloqueante una 
        //confirmación de desbloqueo de todos los drones
        MessageTemplate template1 = MessageTemplate.and(MessageTemplate.MatchContent("loggingOut"),
                MessageTemplate.MatchSender(new AID("CieDroneHQ1", AID.ISLOCALNAME)));
        
        droneReceiver = this.blockingReceive(template1);
        
        System.out.println("Listener ha recibido mensaje de CieDroneHQ1");
        
        MessageTemplate template2 = MessageTemplate.and(MessageTemplate.MatchContent("loggingOut"),
                MessageTemplate.MatchSender(new AID("CieDroneHQ2", AID.ISLOCALNAME)));
        
        droneReceiver = this.blockingReceive(template2);
        
        System.out.println("Listener ha recibido mensaje de CieDroneHQ2");
        
        MessageTemplate template3 = MessageTemplate.and(MessageTemplate.MatchContent("loggingOut"),
                MessageTemplate.MatchSender(new AID("CieDroneHQ3", AID.ISLOCALNAME)));
        
        droneReceiver = this.blockingReceive(template3);
        
        System.out.println("Listener ha recibido mensaje de CieDroneHQ3");
        
        MessageTemplate template4 = MessageTemplate.and(MessageTemplate.MatchContent("loggingOut"),
                MessageTemplate.MatchSender(new AID("CieDroneHQ4", AID.ISLOCALNAME)));
        
        droneReceiver = this.blockingReceive(template4);
        
        System.out.println("Listener ha recibido mensaje de CieDroneHQ4");
        
        // Cancelamos suscripción a World Manager
        worldManagerSender = worldManagerReceiver.createReply();
        worldManagerSender.setProtocol("ANALYTICS");
        worldManagerSender.setPerformative(ACLMessage.CANCEL);
        worldManagerSender.setContent("{}");
        this.send(worldManagerSender);
        
        status = "logoutIM";
    }
    
    /**
     * Envía la información inicial para que cada drone pueda realizar login en el World Manager
     * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
     */
    private void sendInitialInfo(){
        
        // Enviamos a cada drone el id de la conversación, el mapa y su posición
        // inicial en el mundo
        droneSender.setSender(this.getAID());
        droneSender.setPerformative(ACLMessage.INFORM);
        droneSender.setProtocol("INITIALIZE");
        
        // Enviamos info al drone CieDroneHQ1
        droneSender.addReceiver(new AID("CieDroneHQ1", AID.ISLOCALNAME));
        String content = this.getInitialInfoMessage(map.getWidth()/4, map.getHeight()/4).toString();
        droneSender.setContent(content);
        this.send(droneSender);
        
        // Enviamos info al drone CieDroneHQ2
        droneSender.removeReceiver(new AID("CieDroneHQ1", AID.ISLOCALNAME));
        droneSender.addReceiver(new AID("CieDroneHQ2", AID.ISLOCALNAME));
        content = this.getInitialInfoMessage(3*map.getWidth()/4, map.getHeight()/4).toString();
        droneSender.setContent(content);
        this.send(droneSender);
        
        // Enviamos info al drone CieDroneHQ3
        droneSender.removeReceiver(new AID("CieDroneHQ2", AID.ISLOCALNAME));
        droneSender.addReceiver(new AID("CieDroneHQ3", AID.ISLOCALNAME));
        content = this.getInitialInfoMessage(3*map.getWidth()/4, 3*map.getHeight()/4).toString();
        droneSender.setContent(content);
        this.send(droneSender);
        
        // Enviamos info al drone CieDroneHQ4
        droneSender.removeReceiver(new AID("CieDroneHQ3", AID.ISLOCALNAME));
        droneSender.addReceiver(new AID("CieDroneHQ4", AID.ISLOCALNAME));
        content = this.getInitialInfoMessage(map.getWidth()/4, 3*map.getHeight()/4).toString();
        droneSender.setContent(content);
        this.send(droneSender);
        
        status = "logoutWM";
    }
    
}
