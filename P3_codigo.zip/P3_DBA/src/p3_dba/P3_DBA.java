
package p3_dba;

import AppBoot.ConsoleBoot;

/**
 * @author Noelia Escalera Mejías, Fº Javier Casado de Amezúa García, Jesús Torres Sánchez, Iván Valero Rodríguez
 */
public class P3_DBA {

    public static void main(String[] args) {
        ConsoleBoot app = new ConsoleBoot("P3", args);
        app.selectConnection();
        
        // Lanzamos los 6 agentes: Awacs, Listener y 4 Drones
        app.launchAgent("CieAwacs", Awacs.class);
        app.launchAgent("CieListener", CieListener.class);
        app.launchAgent("CieDroneHQ1", CieDroneHQ.class);
        app.launchAgent("CieDroneHQ2", CieDroneHQ.class);
        app.launchAgent("CieDroneHQ3", CieDroneHQ.class);
        app.launchAgent("CieDroneHQ4", CieDroneHQ.class);
        
        app.shutDown();        
    }
    
}